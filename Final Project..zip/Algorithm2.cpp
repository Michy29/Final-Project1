// The algo sorts and reverses the values in the vect
#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>   
#include <ctime>     
int main()
{
  using namespace std;
  srand(time(NULL));       // initialise the PRNG
  vector<int> vect;
  for(int b = 0; b < 10; b++)
    vect.push_back(rand()%10 * ((b % 2)? -1 : 1));
  int b = 0;
  vector<int>::const_iterator it; // iterator declaration
  cout << "take a close look this is the original list of values in our vect  " << endl;
  // for loop with iterators
  for (it = vect.begin(); it != vect.end(); it++)
    cout << "vect[" << b++ << "] = \t" << *it << endl;
  cout << "Tadaa! our algo sorts the list easily" << endl;
  sort(vect.begin(), vect.end()); // sorts the list
  // for loop with iterators
  for (b = 0, it = vect.begin(); it != vect.end(); it++)
    cout << "vect[" << b++ << "] = \t" << *it << endl;
  cout << "We just outdid ourselves and reversed the vect ;)" << endl;
  reverse(vect.begin(), vect.end()); // reverses the list
  // for loop with iterators
  for (b = 0, it = vect.begin(); it != vect.end(); it++)
    cout << "vect[" << b++ << "] = \t" << *it << endl;
}
